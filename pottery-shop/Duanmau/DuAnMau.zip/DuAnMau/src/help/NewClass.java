/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package help;

/**
 *
 * @author admin
 */
public class NewClass {
//    List<NhanVien> list = new ArrayList<NhanVien>();
//        try {
//            ResultSet rs = JdbcHelper.query(sql, args);
//            while (rs.next()) {
//                NhanVien entity = new NhanVien();
//                entity.setMaNV(rs.getString("MaNV"));
//                entity.setHoTen(rs.getString("HoTen"));
//                entity.setMatKhau(rs.getString("MatKhau"));
//                entity.setVaiTro(rs.getBoolean("VaiTro"));
//                list.add(entity);
//            }
//            rs.getStatement().getConnection().close();
//            return list;
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
}
